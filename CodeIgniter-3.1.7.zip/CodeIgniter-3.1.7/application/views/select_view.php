<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Tables</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  </head>
  <body>
    <a href="<?php echo site_url('home/userform/add_user'); ?>">Add employees</a>
    <h3 class="text-center">Employees</h3>
    <div class="table-responsive">
      <table class="table table-hover">
         <tr>
            <th>EmpId</th>
            <th>Name</th>
            <th>Age</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Address</th>
            <th>Actions</th>
         </tr>
         <?php
         if($fetch_data->num_rows()>0){
         foreach ($fetch_data->result() as $row)
         {
            ?><tr>
            <td><?php echo $row->EmpId;?></td>
            <td><?php echo $row->Name;?></td>
            <td><?php echo $row->Age;?></td>
            <td><?php echo $row->Contact;?></td>
            <td><?php echo $row->Email;?></td>
            <td><?php echo $row->Address;?></td>
            <td><a href="<?php echo site_url('home/edit/'.$row->EmpId); ?>">Edit</a> | <a href="<?php echo site_url('home/delete/'.$row->EmpId); ?>">Delete</a> </td>
            </tr>
         <?php }
       }
       else{
         ?>
         <tr>
           <td colspan="3">No Data found</td>
         </tr>
         <?php
       }
       ?>
   </table>
   </div>
</body>
</html>
