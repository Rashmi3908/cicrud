<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Employees</title>
  </head>
  <body>
    <form class="" action="checking" method="post">
      <table>
        <tr>
        <td>Name</td>
        <td><input type="text" name="name" value=""> </td>
      </tr>
      <tr>
        <td>Age</td>
        <td><input type="text" name="age" value=""> </td>
      </tr>
      <tr>
        <td>Contact</td>
        <td><input type="text" name="contact" value=""> </td>
      </tr>
      <tr>
        <td>Email</td>
        <td><input type="text" name="email" value=""> </td>
      </tr>
      <tr>
        <td>Address</td>
        <td><input type="text" name="address" value=""> </td>
      </tr>
      <tr>
        <td><input type="submit" value="Submit" data-toggle="tooltip" title="Click here"></td>
      </tr>
    </table>
    </form>
  </body>
</html>
