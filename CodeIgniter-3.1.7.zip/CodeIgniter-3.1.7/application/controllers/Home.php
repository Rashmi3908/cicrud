
    <?php
       class Home extends CI_Controller
       {

         function __construct(){
           parent::__construct();
           $this->load->database();
           $this->load->model('select');
           $this->load->helper('url_helper');
         }
          public function index()
          {
             //load the database
             $this->load->database();
             //load the model
             $this->load->model('select');
             //load the method of model
             $data['fetch_data']=$this->select->fetch_data();
             //return the data in view
             $this->load->view("select_view", $data);

          }
          public function userform()
          {
          $this->load->view('add_user');
          }
          public function checking()
            {
              $this->load->database();
              $this->load->model('select');
              // print_r($_POST);
            	   	$this->select->model_function($_POST);

            }

          public function delete($id){
            $this->load->database();
            $this->load->model('select');
            // print_r($id);

            $id = $this->uri->segment(3);
            if(empty($id)){
              show_404();
            }
            $row = $this->select->get_by_id($id);

            $this->select->delete($id);
            redirect(base_url(). 'index.php/home');
          }

          // public function edit($id){
          //
          // }

          




         }
    ?>
