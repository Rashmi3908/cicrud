    <?php
       class Select extends CI_Model
       {
          function __construct()
          {
             // Call the Model constructor
             parent::__construct();
          }
          //we will use the select function
          public function fetch_data()
          {
             $query = $this ->db ->get("employees");
             return $query;
          }
          // insert data
          function model_function($arrForm){
            print_r($arrForm);
              $this->db->insert('employees', $arrForm);
              echo "Inserted Successfully";
          }

          public function get_by_id($id=0){
            if($id === 0){
              $query = $this->db->get('employees');
              return $query->row_array();
            }
            $query = $this->db->get_where('employees',array('EmpId'=> $id));
            return $query->row_array();
          }

          public function delete($id){
            $this->db->where('EmpId',$id);
            return $this->db->delete('employees');
          }

       }
    ?>
    <!-- $data = array();
        $query = $this->db->get('users');
        $res   = $query->result();
        return $res; -->
